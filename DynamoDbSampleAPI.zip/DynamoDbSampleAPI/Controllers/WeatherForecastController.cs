using Amazon.DynamoDBv2.DataModel;
using DynamoDbSampleAPI;
using Microsoft.AspNetCore.Mvc;

namespace DynamoDbSample.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly IDynamoDBContext _dynamoDbContext;
        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(IDynamoDBContext dynamoDbContext, ILogger<WeatherForecastController> logger)
        {
            _dynamoDbContext = dynamoDbContext;
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<IEnumerable<WeatherForecast>> Get(string city = "Chennai")
        {
            return await _dynamoDbContext.QueryAsync<WeatherForecast>(city).GetRemainingAsync();
        }

        [HttpPost]
        public async Task Post(string city)
        {
            var data = GetData(city);
            foreach (var item in data)
            {
                await _dynamoDbContext.SaveAsync(item);
            }
        }

        [HttpDelete]
        public async Task Delete(string city)
        {
            DateTime dateTime = DateTime.Now.Date.AddDays(4);
            var specifiedItem = await _dynamoDbContext.LoadAsync<WeatherForecast>(city, dateTime);
            await _dynamoDbContext.DeleteAsync(specifiedItem);
        }
        private IEnumerable<WeatherForecast> GetData(string city)
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                City = city,
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

    }
}